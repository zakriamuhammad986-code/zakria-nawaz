import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  Mail, Phone, Linkedin, Github, Download, ArrowRight, MapPin, Map, Satellite,
  BarChart3, PenTool, Code2, GraduationCap, Briefcase, Award, X, Menu,
} from "lucide-react";

const TITLE = "Muhammad Zakria Nawaz — Geo-Informatics, GIS & Remote Sensing";
const DESC =
  "Portfolio of Muhammad Zakria Nawaz, BS Geo-Informatics student at PMAS-Arid Agriculture University: GIS, remote sensing, spatial analysis and WebGIS projects.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const EMAIL = "zakriamuhammad986@gmail.com";
const PHONE = "03065835015";
const LINKEDIN = "https://www.linkedin.com/in/muhammad-zakria-nawaz/";
const GITHUB = "https://github.com/zakriamuhammad986-code";
const CV = "/documents/Zakria-CV.pdf";

const NAV = ["Home", "About", "Education", "Skills", "Experience", "Projects", "Services", "Contact"];

type Category = "GIS Analysis" | "Remote Sensing" | "WebGIS" | "Spatial Analysis";
type Project = {
  n: string; title: string; place: string; date: string; category: Category;
  tools: string[]; desc: string; img: string; alt: string; link?: string;
};

const PROJECTS: Project[] = [
  {
    n: "01", title: "Groundwater Potential Zonation via MCDA", place: "Balochistan",
    date: "Mar 2026 – May 2026", category: "GIS Analysis",
    tools: ["Weighted Overlay", "Euclidean Distance", "Slope", "Aspect", "Spatial Buffers", "Reclassify"],
    desc: "Conducted a Multi-Criteria Decision Analysis (MCDA) to identify potential groundwater zones in the arid region of Balochistan. Integrated and weighted multiple topographical and geological parameters to identify suitable areas for groundwater exploration and resource planning.",
    img: "/images/groundwater.jpg", alt: "Groundwater potential zonation map of Balochistan showing suitability classes",
  },
  {
    n: "02", title: "Land Subsidence Detection via Sentinel-1 InSAR", place: "Lahore",
    date: "Nov 2025 – Jan 2026", category: "Remote Sensing",
    tools: ["Sentinel-1 SAR", "InSAR", "Raster Calculator", "Hillshade", "Slope Extraction", "Contours", "Extract by Mask"],
    desc: "Analyzed Sentinel-1 Synthetic Aperture Radar data and supporting terrain information to investigate land subsidence patterns in Lahore. Processed and visualized spatial information to examine ground deformation and potential infrastructure risks.",
    img: "/images/subsidence.jpg", alt: "Sentinel-1 InSAR processing output for Lahore",
  },
  {
    n: "03", title: "WebGIS Health Facility Portal", place: "Islamabad & Rawalpindi",
    date: "Dec 2025 – Jan 2026", category: "WebGIS",
    tools: ["HTML5", "CSS3", "JavaScript", "Leaflet.js", "VS Code", "GitHub"],
    desc: "Developed an interactive WebGIS platform to visualize healthcare facility locations in Islamabad and Rawalpindi. Used Leaflet.js for interactive map rendering and modern web technologies to provide accessible geospatial information.",
    img: "/images/webgis.png", alt: "Screenshot of the interactive WebGIS health facility map", link: "https://mzakrianawaz-debug.github.io/zakria_nawaz/#map",
  },
  {
    n: "04", title: "Balochistan 20-Year Environmental Spatiotemporal Analysis", place: "Balochistan",
    date: "Mar 2024 – May 2024", category: "Remote Sensing",
    tools: ["ArcGIS", "Clip", "Extract by Mask", "Raster Calculator", "Zonal/Cell Statistics", "Reclassify", "Supervised/Unsupervised Classification"],
    desc: "Processed two decades (2000–2020) of longitudinal orbital satellite data to empirically analyze ecological degradation. Computed and compared vital environmental indices including NDVI (vegetation health), LST (surface temperature emissions), LULC (land cover shifts), and localized precipitation mapping to quantify the rate of regional desertification.",
    img: "/images/balochistan.png", alt: "Balochistan 20-year NDVI, LST, LULC and precipitation analysis maps",
  },
  {
    n: "05", title: "Network Analysis for Emergency Healthcare Accessibility", place: "Rawalpindi",
    date: "May 2025 – Jun 2025", category: "Spatial Analysis",
    tools: ["Network Analyst", "Intersect", "Spatial Join", "Service Buffers"],
    desc: "Analyzed the urban road network of Rawalpindi to evaluate emergency healthcare accessibility. Applied network analysis, spatial joins, and service-area techniques to investigate hospital accessibility and efficient routing possibilities.",
    img: "/images/network.jpg", alt: "Rawalpindi hospital accessibility map with road network and service areas",
  },
];

const SERVICES = [
  { icon: Map, t: "GIS Mapping & Map Design", d: "Thematic and reference maps with clear symbology, layouts and cartographic standards." },
  { icon: Satellite, t: "Remote Sensing & Imagery Analysis", d: "Satellite image processing, classification, NDVI and land use / land cover studies." },
  { icon: BarChart3, t: "Spatial Data Analysis", d: "Overlay, buffer, network and multi-criteria analysis to answer location-based questions." },
  { icon: PenTool, t: "Digitization & Georeferencing", d: "Converting scanned maps and imagery into accurate, georeferenced vector datasets." },
  { icon: Code2, t: "Basic Web Development", d: "Simple, responsive websites and map pages built with HTML, CSS and JavaScript." },
];

/** Shows the real file from /public; if it is missing, shows a clearly labelled placeholder. */
function Asset({ src, alt, label, className = "" }: { src: string; alt: string; label: string; className?: string }) {
  const [failed, setFailed] = useState(false);
  const ref = useRef<HTMLImageElement>(null);
  useEffect(() => {
    const i = ref.current;
    if (!i) return;
    // Re-check after hydration: an error before React attached its handler would be missed.
    const probe = new Image();
    probe.onerror = () => setFailed(true);
    probe.src = src;
  }, [src]);
  if (failed)
    return (
      <div role="img" aria-label={alt} className={`flex flex-col items-center justify-center gap-2 bg-earth p-4 text-center ${className}`}>
        <MapPin className="h-6 w-6 text-gold" />
        <span className="text-sm font-semibold text-paper">{label}</span>
        <span className="font-mono text-[0.65rem] text-sage">Placeholder · upload {src}</span>
      </div>
    );
  return <img ref={ref} src={src} alt={alt} loading="lazy" onError={() => setFailed(true)} className={`object-cover ${className}`} />;
}

function Section({ id, eyebrow, title, children, dark }: { id: string; eyebrow: string; title: string; children: ReactNode; dark?: boolean }) {
  return (
    <section id={id} className={dark ? "bg-forest text-paper" : ""}>
      <div className="mx-auto max-w-6xl px-6 py-24">
        <p className="eyebrow">{eyebrow}</p>
        <h2 className="mt-3 max-w-2xl text-3xl font-bold tracking-tight md:text-4xl">{title}</h2>
        <div className="mt-12">{children}</div>
      </div>
    </section>
  );
}

const btn = "inline-flex items-center gap-2 rounded-md px-5 py-3 text-sm font-semibold transition-colors";
const btnGold = `${btn} bg-gold text-forest hover:bg-sage`;
const btnLine = `${btn} border border-sage/40 text-paper hover:border-gold hover:text-gold`;

function Index() {
  const [menu, setMenu] = useState(false);
  const [filter, setFilter] = useState<"All" | Category>("All");
  const [open, setOpen] = useState<Project | null>(null);
  const shown = filter === "All" ? PROJECTS : PROJECTS.filter((p) => p.category === filter);

  return (
    <div className="font-sans">
      {/* NAV */}
      <header className="sticky top-0 z-40 border-b border-sage/15 bg-forest/95 text-paper backdrop-blur">
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <a href="#home" className="flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-sm border border-gold font-mono text-sm font-medium text-gold">MZ</span>
            <span className="hidden text-sm font-semibold sm:block">Zakria Nawaz</span>
          </a>
          <ul className="hidden gap-6 text-sm lg:flex">
            {NAV.map((n) => (
              <li key={n}><a href={`#${n.toLowerCase()}`} className="text-sage hover:text-gold">{n}</a></li>
            ))}
          </ul>
          <button className="lg:hidden" aria-label="Toggle menu" onClick={() => setMenu(!menu)}>
            {menu ? <X /> : <Menu />}
          </button>
        </nav>
        {menu && (
          <ul className="border-t border-sage/15 px-6 py-4 lg:hidden">
            {NAV.map((n) => (
              <li key={n}><a onClick={() => setMenu(false)} href={`#${n.toLowerCase()}`} className="block py-2 text-sage">{n}</a></li>
            ))}
          </ul>
        )}
      </header>

      {/* HERO */}
      <section id="home" className="relative overflow-hidden bg-forest text-paper">
        <div className="mx-auto grid max-w-6xl items-center gap-14 px-6 py-24 md:grid-cols-[1.3fr_1fr] md:py-32">
          <div>
            <h1 className="text-4xl font-extrabold leading-[1.05] tracking-tight md:text-6xl">Muhammad Zakria Nawaz</h1>
            <p className="mt-4 text-lg font-medium text-gold">Geo-Informatics Student | GIS & Remote Sensing Enthusiast</p>
            <p className="mt-6 max-w-xl leading-relaxed text-sage">
              I am an aspiring Geo-Informatics professional passionate about GIS, Remote Sensing, Spatial Data Analysis, and Geospatial Technologies. I enjoy transforming complex geographical data into meaningful maps, spatial insights, and practical solutions. My goal is to combine geospatial knowledge with modern web technologies to build innovative, data-driven applications.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <a href="#projects" className={btnGold}>View My Projects <ArrowRight className="h-4 w-4" /></a>
              <a href={CV} target="_blank" rel="noreferrer" download="Zakria-CV.pdf" className={btnLine}><Download className="h-4 w-4" /> Download CV</a>
              <a href="#contact" className={btnLine}>Contact Me</a>
            </div>
            <div className="mt-8 flex gap-4 text-sage">
              <a href={LINKEDIN} target="_blank" rel="noreferrer" aria-label="LinkedIn" className="hover:text-gold"><Linkedin /></a>
              <a href={GITHUB} target="_blank" rel="noreferrer" aria-label="GitHub" className="hover:text-gold"><Github /></a>
            </div>
          </div>
          <div className="relative mx-auto w-full max-w-sm">
            <div className="absolute -inset-3 rounded-sm border border-gold/40" />
            <Asset src="/images/profile.jpg" alt="Portrait of Muhammad Zakria Nawaz" label="Profile photograph" className="relative aspect-[4/5] w-full rounded-sm" />
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <Section id="about" eyebrow="01 · About" title="Turning geographic data into decisions.">
        <div className="grid gap-12 md:grid-cols-2">
          <div className="space-y-5 leading-relaxed text-muted-foreground">
            <p>I am a 7th-semester BS Geo-Informatics student at PMAS-Arid Agriculture University, Rawalpindi. My coursework and projects focus on how spatial data can explain real problems — from water resources in arid regions to healthcare access in growing cities.</p>
            <p>Alongside geospatial work, I am building web development skills so that maps and analysis can reach people through simple, accessible applications.</p>
            <div className="border-l-2 border-gold pl-5">
              <p className="eyebrow">Career objective</p>
              <p className="mt-2 text-foreground">To develop practical expertise in geospatial technologies and software development while contributing to innovative solutions in environmental monitoring, spatial planning, and geographic information systems.</p>
            </div>
          </div>
          <ul className="divide-y divide-border border-y border-border">
            {["GIS and Spatial Analysis", "Remote Sensing and Satellite Imagery", "Environmental Monitoring", "Digital Image Processing", "WebGIS and Geospatial Applications"].map((t, i) => (
              <li key={t} className="flex items-center gap-5 py-4">
                <span className="font-mono text-xs text-gold">0{i + 1}</span>
                <span className="font-semibold">{t}</span>
              </li>
            ))}
          </ul>
        </div>
      </Section>

      {/* EDUCATION */}
      <section id="education" className="bg-muted">
        <div className="mx-auto max-w-6xl px-6 py-24">
          <p className="eyebrow">02 · Education & Certifications</p>
          <h2 className="mt-3 text-3xl font-bold tracking-tight md:text-4xl">Academic foundation</h2>
          <div className="mt-12 grid gap-6 lg:grid-cols-3">
            <article className="rounded-lg border border-border bg-card p-7 lg:row-span-2">
              <GraduationCap className="h-6 w-6 text-gold" />
              <p className="mt-5 font-mono text-xs text-muted-foreground">2023 – 2027</p>
              <h3 className="mt-2 text-xl font-bold">BS Geo-Informatics</h3>
              <p className="mt-1 text-muted-foreground">PMAS-Arid Agriculture University, Rawalpindi</p>
              <dl className="mt-6 space-y-2 text-sm">
                <div className="flex justify-between border-t border-border pt-2"><dt className="text-muted-foreground">Status</dt><dd className="font-semibold">Currently enrolled</dd></div>
                <div className="flex justify-between border-t border-border pt-2"><dt className="text-muted-foreground">Semester</dt><dd className="font-semibold">7th</dd></div>
              </dl>
            </article>
            {[
              { t: "Geographic Information Systems (GIS) Specialization", i: "University of California, Davis" },
              { t: "Introduction to Software Engineering", i: "IBM" },
            ].map((c) => (
              <article key={c.t} className="rounded-lg border border-border bg-card p-7 lg:col-span-2">
                <div className="flex items-start gap-4">
                  <Award className="mt-1 h-5 w-5 shrink-0 text-gold" />
                  <div>
                    <h3 className="font-bold">{c.t}</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{c.i} · Coursera</p>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* SKILLS */}
      <Section id="skills" eyebrow="03 · Skills" title="Tools and methods I work with.">
        <div className="grid gap-6 md:grid-cols-[2fr_1fr]">
          {[
            { h: "GIS & Remote Sensing", s: ["GIS Mapping", "QGIS", "ArcGIS", "Remote Sensing", "Spatial Analysis", "Satellite Imagery Analysis", "Digitization", "NDVI", "Land Use / Land Cover", "Georeferencing"] },
            { h: "Web Development", s: ["HTML5", "CSS3", "JavaScript"] },
          ].map((g) => (
            <div key={g.h} className="rounded-lg border border-border bg-card p-7">
              <h3 className="font-bold">{g.h}</h3>
              <ul className="mt-5 flex flex-wrap gap-2">
                {g.s.map((s) => <li key={s} className="rounded-sm border border-border bg-secondary px-3 py-1.5 text-sm">{s}</li>)}
              </ul>
            </div>
          ))}
        </div>
      </Section>

      {/* EXPERIENCE */}
      <Section id="experience" eyebrow="04 · Experience" title="Professional experience" dark>
        <div className="relative border-l border-sage/30 pl-8">
          <span className="absolute -left-[5px] top-1 h-2.5 w-2.5 rounded-full bg-gold" />
          <p className="font-mono text-xs text-sage">Jul – Sep 2026 · 6 weeks</p>
          <h3 className="mt-2 flex items-center gap-2 text-xl font-bold"><Briefcase className="h-5 w-5 text-gold" /> Intern — Fauji Cement Company Limited (FCCL)</h3>
          <ul className="mt-5 grid gap-2 text-sage sm:grid-cols-2">
            {["Computer operations", "Domain change tasks", "MIS-related tasks", "Basic IT and administrative technical support"].map((r) => (
              <li key={r} className="flex gap-3"><span className="text-gold">—</span>{r}</li>
            ))}
          </ul>
        </div>
      </Section>

      {/* PROJECTS */}
      <Section id="projects" eyebrow="05 · Featured projects" title="Five selected projects.">
        <div className="mb-8 flex flex-wrap gap-2" role="tablist">
          {(["All", "GIS Analysis", "Remote Sensing", "WebGIS", "Spatial Analysis"] as const).map((c) => (
            <button key={c} onClick={() => setFilter(c)} aria-pressed={filter === c}
              className={`rounded-sm border px-4 py-2 text-sm font-medium transition-colors ${filter === c ? "border-forest bg-forest text-paper" : "border-border hover:border-forest"}`}>
              {c}
            </button>
          ))}
        </div>
        <div className="grid gap-8 md:grid-cols-2">
          {shown.map((p, i) => (
            <article key={p.n} className={`group overflow-hidden rounded-lg border border-border bg-card transition-shadow hover:shadow-lg ${filter === "All" && i === 0 ? "md:col-span-2" : ""}`}>
              <div className="overflow-hidden">
                <Asset src={p.img} alt={p.alt} label={`Project ${p.n} map`} className={`w-full transition-transform duration-500 group-hover:scale-[1.02] h-auto`} />
              </div>
              <div className="p-7">
                <div className="flex items-center justify-between font-mono text-xs">
                  <span className="text-gold">{p.n} · {p.category}</span>
                  <span className="text-muted-foreground">{p.date}</span>
                </div>
                <h3 className="mt-3 text-xl font-bold">{p.title} <span className="font-medium text-muted-foreground">({p.place})</span></h3>
                <p className="mt-3 line-clamp-2 text-sm leading-relaxed text-muted-foreground">{p.desc}</p>
                <ul className="mt-4 flex flex-wrap gap-1.5">
                  {p.tools.slice(0, 4).map((t) => <li key={t} className="rounded-sm bg-secondary px-2 py-1 text-xs">{t}</li>)}
                </ul>
                <button onClick={() => setOpen(p)} className="mt-6 inline-flex items-center gap-2 text-sm font-semibold hover:text-gold">
                  View Details <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </Section>

      {/* SERVICES */}
      <section id="services" className="bg-muted">
        <div className="mx-auto max-w-6xl px-6 py-24">
          <p className="eyebrow">06 · Services</p>
          <h2 className="mt-3 text-3xl font-bold tracking-tight md:text-4xl">How I can help</h2>
          <div className="mt-12 grid gap-px overflow-hidden rounded-lg border border-border bg-border sm:grid-cols-2 lg:grid-cols-3">
            {SERVICES.map(({ icon: Icon, t, d }) => (
              <div key={t} className="bg-card p-7">
                <Icon className="h-6 w-6 text-gold" />
                <h3 className="mt-5 font-bold">{t}</h3>
                <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{d}</p>
              </div>
            ))}
            <a href="#contact" className="flex flex-col justify-between bg-forest p-7 text-paper hover:bg-earth">
              <span className="eyebrow">Open to work</span>
              <span className="mt-6 flex items-center gap-2 text-lg font-bold">Start a conversation <ArrowRight className="h-5 w-5 text-gold" /></span>
            </a>
          </div>
        </div>
      </section>

      <Contact />

      {/* FOOTER */}
      <footer className="border-t border-sage/15 bg-forest text-sage">
        <div className="mx-auto grid max-w-6xl gap-8 px-6 py-12 md:grid-cols-3">
          <div>
            <p className="font-bold text-paper">Muhammad Zakria Nawaz</p>
            <p className="mt-1 text-sm">Geo-Informatics | GIS | Remote Sensing</p>
            <a href={`mailto:${EMAIL}`} className="mt-3 block text-sm hover:text-gold">{EMAIL}</a>
          </div>
          <ul className="grid grid-cols-2 gap-2 text-sm">
            {NAV.map((n) => <li key={n}><a href={`#${n.toLowerCase()}`} className="hover:text-gold">{n}</a></li>)}
          </ul>
          <div className="flex gap-4 md:justify-end">
            <a href={LINKEDIN} target="_blank" rel="noreferrer" aria-label="LinkedIn" className="hover:text-gold"><Linkedin /></a>
            <a href={GITHUB} target="_blank" rel="noreferrer" aria-label="GitHub" className="hover:text-gold"><Github /></a>
          </div>
        </div>
        <p className="border-t border-sage/15 py-5 text-center font-mono text-xs">© {new Date().getFullYear()} Muhammad Zakria Nawaz</p>
      </footer>

      {open && (
        <div role="dialog" aria-modal="true" aria-label={open.title} className="fixed inset-0 z-50 flex items-center justify-center bg-forest/80 p-4" onClick={() => setOpen(null)}>
          <div className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-lg bg-card" onClick={(e) => e.stopPropagation()}>
            <Asset src={open.img} alt={open.alt} label={`Project ${open.n} map`} className="h-auto w-full" />
            <div className="p-8">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-mono text-xs text-gold">{open.n} · {open.category} · {open.date}</p>
                  <h3 className="mt-2 text-2xl font-bold">{open.title}</h3>
                  <p className="text-muted-foreground">{open.place}</p>
                </div>
                <button onClick={() => setOpen(null)} aria-label="Close"><X /></button>
              </div>
              <p className="mt-5 leading-relaxed text-muted-foreground">{open.desc}</p>
              {open.link && <a href={open.link} target="_blank" rel="noreferrer" className="mt-4 inline-block font-semibold text-gold underline">View live WebGIS map →</a>}
              <p className="eyebrow mt-6">Tools & techniques</p>
              <ul className="mt-3 flex flex-wrap gap-2">
                {open.tools.map((t) => <li key={t} className="rounded-sm border border-border bg-secondary px-3 py-1 text-sm">{t}</li>)}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Contact() {
  const [err, setErr] = useState("");
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const name = String(f.get("name")).trim(), email = String(f.get("email")).trim();
    const subject = String(f.get("subject")).trim(), message = String(f.get("message")).trim();
    if (!name || !subject || message.length < 10) return setErr("Please fill in all fields (message at least 10 characters).");
    if (!/^\S+@\S+\.\S+$/.test(email)) return setErr("Please enter a valid email address.");
    setErr("");
    // Opens the visitor's email app with the message pre-filled.
    window.location.href = `mailto:${EMAIL}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(`${message}\n\n— ${name} (${email})`)}`;
  };
  const field = "w-full rounded-md border border-input bg-card px-4 py-3 text-sm outline-none focus:border-gold";
  return (
    <Section id="contact" eyebrow="07 · Contact" title="Let's work together.">
      <div className="grid gap-12 md:grid-cols-[1fr_1.4fr]">
        <div>
          <p className="leading-relaxed text-muted-foreground">I'm currently open to internships, research collaborations and freelance GIS work. Feel free to reach out.</p>
          <ul className="mt-8 space-y-4 text-sm">
            <li><a href={`mailto:${EMAIL}`} className="flex items-center gap-3 hover:text-gold"><Mail className="h-4 w-4 text-gold" />{EMAIL}</a></li>
            <li><a href={`tel:+92${PHONE.slice(1)}`} className="flex items-center gap-3 hover:text-gold"><Phone className="h-4 w-4 text-gold" />{PHONE}</a></li>
            <li><a href={LINKEDIN} target="_blank" rel="noreferrer" className="flex items-center gap-3 hover:text-gold"><Linkedin className="h-4 w-4 text-gold" />LinkedIn</a></li>
            <li><a href={GITHUB} target="_blank" rel="noreferrer" className="flex items-center gap-3 hover:text-gold"><Github className="h-4 w-4 text-gold" />GitHub</a></li>
          </ul>
        </div>
        <form onSubmit={submit} noValidate className="grid gap-4 rounded-lg border border-border bg-muted p-7 sm:grid-cols-2">
          <input name="name" placeholder="Name" aria-label="Name" className={field} maxLength={100} />
          <input name="email" type="email" placeholder="Email" aria-label="Email" className={field} maxLength={255} />
          <input name="subject" placeholder="Subject" aria-label="Subject" className={`${field} sm:col-span-2`} maxLength={150} />
          <textarea name="message" rows={5} placeholder="Message" aria-label="Message" className={`${field} sm:col-span-2`} maxLength={2000} />
          {err && <p className="text-sm text-destructive sm:col-span-2">{err}</p>}
          <button className={`${btn} justify-center bg-forest text-paper hover:bg-earth sm:col-span-2`}>Send message <ArrowRight className="h-4 w-4" /></button>
        </form>
      </div>
    </Section>
  );
}

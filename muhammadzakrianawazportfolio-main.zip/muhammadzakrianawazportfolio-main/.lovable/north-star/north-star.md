<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Recruiters and clients see the builder's GIS work and get in touch about hiring.

## Metric

Visitors who download the CV or send a contact message each month
